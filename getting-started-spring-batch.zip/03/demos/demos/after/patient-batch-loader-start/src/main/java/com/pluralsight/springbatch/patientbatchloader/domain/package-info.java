/**
 * JPA domain objects.
 */
package com.pluralsight.springbatch.patientbatchloader.domain;
