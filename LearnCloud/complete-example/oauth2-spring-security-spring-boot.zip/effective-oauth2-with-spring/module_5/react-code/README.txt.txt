React crypto client, to run the application from this, you need Node installed.

Then in the "crypto-portfolio-client" folder execure
npm install
npm start

http://localhost:3000/portfolio

Ensure the portfolio and support services are running.