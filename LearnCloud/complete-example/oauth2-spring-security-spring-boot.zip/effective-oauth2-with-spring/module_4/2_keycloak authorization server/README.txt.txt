In order for this demo to run, you need to setup a keycloak server to run on port: 8081
You will also need to create a user in keycloak, see the course for this module on how to do this.
Any issues please feel free to message me in the discussion.
I have included the "realm-export.json" file in the parent folder, you can use that to setup the Realm 
and all the clients, roles and users
via the admin console in Manage -> Import.