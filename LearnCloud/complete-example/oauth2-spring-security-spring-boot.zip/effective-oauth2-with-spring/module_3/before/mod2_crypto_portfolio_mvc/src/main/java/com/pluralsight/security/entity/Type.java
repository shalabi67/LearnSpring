package com.pluralsight.security.entity;

public enum Type {

	BUY, SELL;
	
}
