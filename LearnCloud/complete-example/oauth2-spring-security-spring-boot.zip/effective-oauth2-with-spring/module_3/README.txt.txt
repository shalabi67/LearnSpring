You will need to source a client id and secret from facebook and google and update the application.yml file with
these details