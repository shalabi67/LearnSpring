# todo-app

This repository contains a simple todo application built with Spring Boot

## Build

Build with the included Maven wrapper

    ./mvnw clean install

## Usage

Run via command line

    ./mvnw spring-boot:run

# Found a bug?

Fork, improve and PR. ;-)

# Questions / Comments

Contact me at [http://dustin.schultz.io](http://dustin.schultz.io/)
